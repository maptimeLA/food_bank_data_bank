import os, csv

csvfile = open("2014LAMarketViolations.csv","rb")
cleanedCSV = open("cleanedViolations.csv","wb")

header = ["Activity Date","Record ID","Name","Address","cityStateZip","lat","lon","Program Element Code","Program Element Code Description","Service Description","Violation Code","Violation Code Description","Violation Points","Score","Grade","Count","SERVICE"]

writer = csv.writer(cleanedCSV,delimiter=",",quotechar='"',quoting=csv.QUOTE_ALL)
writer.writerow(header)

with open("2014LAMarketViolations.csv",'rb') as f:
	reader = csv.reader(f,delimiter=',',quotechar='"',quoting=csv.QUOTE_ALL)
	x = 0
	for row in reader:

		if x == 0:			
			x += 1
			pass
		else:
				
			oldaddress = row[3]
			oldcityStateZip = row[4]
			oldlatlon = row[5]			
			
			if row[6] == "":
				newlatlon = row[5].split(', ')
				newaddress = oldaddress
				newcityStateZip = oldcityStateZip
			else:
				newlatlon = row[6].split(', ')
				newaddress = oldaddress + oldcityStateZip
				newcityStateZip = oldlatlon
				
			newRow = [row[0],row[1],row[2],newaddress,newcityStateZip,newlatlon[0][1:],newlatlon[1][:-1],row[7],row[8],row[9],row[10],row[11],row[12],row[13],row[14],row[15],row[16]]
			if x < 10:
				print newRow
				x += 1
			writer.writerow(newRow)
		
f.close()


        